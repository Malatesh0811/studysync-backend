"""StudySync CLI package."""
