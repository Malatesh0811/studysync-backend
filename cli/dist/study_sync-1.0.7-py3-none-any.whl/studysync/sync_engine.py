"""
sync_engine.py — Core networking and sync logic for StudySync CLI.

Two-phase upload
----------------
1. POST /upload-request  → {presigned_put_url, pending_upload_id}
2. PUT presigned_put_url (raw bytes)
3. POST /commit-upload   → updated file record

Optimistic concurrency control
-------------------------------
Every push includes base_version.  If that doesn't match the server's
latest_version the server returns HTTP 409.  The client must pull first.

Alias resolution
-----------------
Users can join with a short workspace alias (name) instead of a raw UUID.
SyncEngine.resolve_alias() calls GET /alias/{alias} on the backend, which
returns the workspace's access_token.
"""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path
from typing import Any

import requests
from requests import HTTPError, Session
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table

from .constants import PRODUCTION_SERVER_URL
from .local_state import (
    all_local_files,
    ensure_dirs,
    load_config,
    load_manifest,
    local_file_path,
    save_manifest,
    sha256_file,
    update_manifest_entry,
    workspace_root,
    WORKSPACES_DIR,
)

console = Console()

# ---------------------------------------------------------------------------
# Progress-aware file reader
# ---------------------------------------------------------------------------

class _ProgressReader:
    """Wrap a file so requests streams it while updating a Rich progress bar."""

    def __init__(self, path: Path, task_id: Any, progress: Progress) -> None:
        self._fh = open(path, "rb")
        self._task_id = task_id
        self._progress = progress
        self._size = path.stat().st_size

    def read(self, size: int = -1) -> bytes:
        chunk = self._fh.read(size)
        if chunk:
            self._progress.update(self._task_id, advance=len(chunk))
        return chunk

    def __len__(self) -> int:
        return self._size

    def close(self) -> None:
        self._fh.close()

    def __enter__(self) -> "_ProgressReader":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# SyncEngine
# ---------------------------------------------------------------------------

class SyncEngine:
    """Handles all communication with the StudySync backend."""

    def __init__(self, server_url: str | None = None) -> None:
        ensure_dirs()
        config = load_config()
        raw_url = server_url or config.get("server_url", PRODUCTION_SERVER_URL)
        self.base_url: str = raw_url.rstrip("/")
        self.workspace_id: str = config.get("workspace_id", "")
        self.workspace_name: str = config.get("workspace_name", "")
        self.token: str = config.get("workspace_token", "")

        self.session: Session = requests.Session()
        if self.token:
            self.session.headers["Authorization"] = f"Bearer {self.token}"
        self.session.headers["User-Agent"] = "studysync-cli/1.0"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _raise_for_status(self, resp: requests.Response) -> None:
        """Raise HTTPError with the backend's JSON detail if present."""
        if resp.ok:
            return
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise HTTPError(
            f"HTTP {resp.status_code}: {detail}",
            response=resp,
        )

    def _require_workspace(self) -> None:
        """Abort with a friendly message if no workspace is configured."""
        if not self.workspace_id or not self.token:
            console.print(
                Panel(
                    "No workspace is configured.\n\n"
                    "Create one:  [cyan]study workspace create <name>[/cyan]\n"
                    "Or join one: [cyan]study join <token-or-alias>[/cyan]",
                    title="[bold red]✗ Not configured[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    # ------------------------------------------------------------------
    # Workspace management
    # ------------------------------------------------------------------

    def create_workspace(self, name: str) -> dict[str, Any]:
        """POST /workspaces — create a new workspace; returns {workspace_id, access_token, name}."""
        resp = self.session.post(
            f"{self.base_url}/workspaces",
            json={"name": name},
            timeout=30,
        )
        self._raise_for_status(resp)
        data = resp.json()
        return {
            "workspace_id": data["workspace_id"],
            "access_token": data["access_token"],
            "name": data["name"],
        }

    def join_workspace(self, token: str) -> dict[str, Any]:
        """GET /workspaces/{token} — validate token; returns {workspace_id, name}."""
        resp = self.session.get(
            f"{self.base_url}/workspaces/{token}",
            timeout=30,
        )
        self._raise_for_status(resp)
        data = resp.json()
        return {
            "workspace_id": data["workspace_id"],
            "name": data["name"],
        }

    def resolve_input(self, token_or_alias: str) -> dict:
        """
        GET /resolve/{input} — resolve a token or alias to workspace info.

        The backend checks its Aliases table first.  If the input is not a
        known alias it tries to interpret it as a raw UUID access_token.

        Returns
        -------
        dict
            Keys: ``resolved_from_alias`` (bool), ``alias`` (str | None),
            ``workspace_id``, ``name``, ``access_token``.

        Raises
        ------
        SystemExit
            Prints a red error panel and exits 1 on HTTP 404 or connection
            failure.
        """
        try:
            resp = self.session.get(
                f"{self.base_url}/resolve/{token_or_alias}",
                timeout=15,
            )
            self._raise_for_status(resp)
            return resp.json()
        except HTTPError as exc:
            code = exc.response.status_code if exc.response is not None else "?"
            try:
                detail = exc.response.json().get("detail", str(exc))
            except Exception:
                detail = str(exc)
            console.print(
                Panel(
                    f"{detail}",
                    title=f"[bold red]✗ Could not resolve '{token_or_alias}'[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)
        except requests.ConnectionError:
            console.print(
                Panel(
                    f"Could not reach [cyan]{self.base_url}[/cyan].\n"
                    "Check your network connection or --server URL.",
                    title="[bold red]✗ Connection error[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    # ------------------------------------------------------------------
    # Pull
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Pull helpers
    # ------------------------------------------------------------------

    # ===========================================================================
    # pull  — server is always source of truth
    # ===========================================================================

    def pull(self) -> None:
        """
        Download every file from the remote workspace that is missing or
        out-of-date locally.

        "Missing" means either:
          - the file is not in the local manifest at all (first pull after join), OR
          - the file IS in the manifest but the physical file is gone from disk.

        "Out-of-date" means:
          - the server has a higher version number.

        Both conditions force a download so the local directory always matches
        the server without any user intervention.
        """
        self._require_workspace()

        # ── 1. Fetch server state ─────────────────────────────────────────
        with console.status("[blue]Fetching workspace state…[/blue]", spinner="dots"):
            try:
                resp = self.session.get(
                    f"{self.base_url}/sync/state/{self.token}",
                    timeout=30,
                )
                self._raise_for_status(resp)
            except (HTTPError, requests.ConnectionError) as exc:
                console.print(
                    Panel(str(exc),
                          title="[bold red]✗ Pull failed[/bold red]",
                          border_style="red", padding=(1, 2))
                )
                sys.exit(1)

        remote_files: list[dict] = resp.json().get("files", [])
        if not remote_files:
            console.print("[dim]Remote workspace is empty — nothing to pull.[/dim]")
            return

        # ── 2. Decide what to download ────────────────────────────────────
        manifest = load_manifest()
        cwd = Path(os.getcwd())

        to_download: list[dict] = []
        for rf in remote_files:
            fp              = rf["file_path"]
            remote_ver      = rf["latest_version"]
            local_ver       = manifest.get(fp, {}).get("version", 0)
            file_on_disk    = (cwd / fp).exists()

            if not file_on_disk or local_ver < remote_ver:
                to_download.append(rf)

        if not to_download:
            console.print(
                Panel(
                    f"All {len(remote_files)} file(s) are up to date.",
                    title="[bold green]✓ Already in sync[/bold green]",
                    border_style="green", padding=(0, 2),
                )
            )
            return

        # ── 3. Download each file ─────────────────────────────────────────
        updated: list[str] = []
        errors:  list[str] = []

        progress = Progress(
            TextColumn("[bold blue]{task.fields[filename]}"),
            BarColumn(), DownloadColumn(),
            TransferSpeedColumn(), TimeRemainingColumn(),
            console=console,
        )

        with progress:
            for rf in to_download:
                fp       = rf["file_path"]
                version  = rf["latest_version"]
                checksum = rf.get("latest_checksum") or ""
                size     = rf.get("size_bytes") or 0

                task_id = progress.add_task(
                    "dl", filename=fp,
                    total=size if size > 0 else None,
                )

                # Request presigned GET URL
                try:
                    dl = self.session.get(
                        f"{self.base_url}/sync/download-request",
                        params={"workspace_token": self.token, "file_path": fp},
                        timeout=30,
                    )
                    self._raise_for_status(dl)
                except (HTTPError, requests.ConnectionError) as exc:
                    errors.append(f"{fp}: {exc}")
                    progress.update(task_id, visible=False)
                    continue

                presigned_url = dl.json()["presigned_url"]

                # Stream to vault
                vault_path = local_file_path(self.workspace_name, fp)
                vault_path.parent.mkdir(parents=True, exist_ok=True)
                try:
                    with requests.get(presigned_url, stream=True, timeout=120) as r:
                        self._raise_for_status(r)
                        with open(vault_path, "wb") as fh:
                            for chunk in r.iter_content(65_536):
                                fh.write(chunk)
                                progress.update(task_id, advance=len(chunk))
                except Exception as exc:
                    errors.append(f"{fp}: {exc}")
                    progress.update(task_id, visible=False)
                    continue

                # Verify checksum
                if checksum and sha256_file(vault_path) != checksum:
                    vault_path.unlink(missing_ok=True)
                    errors.append(f"{fp}: checksum mismatch — file discarded, try again")
                    progress.update(task_id, visible=False)
                    continue

                # Write to working directory
                dest = cwd / fp
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(vault_path, dest)

                update_manifest_entry(fp, version, checksum)
                updated.append(fp)

        # ── 4. Report ─────────────────────────────────────────────────────
        if updated:
            console.print(
                Panel(
                    "\n".join(f"  [green]✓[/green] {f}" for f in updated),
                    title=f"[bold green]✓ Pulled {len(updated)} file(s)[/bold green]",
                    border_style="green", padding=(1, 2),
                )
            )
        if errors:
            console.print(
                Panel(
                    "\n".join(f"  [red]✗[/red] {e}" for e in errors),
                    title="[bold red]✗ Some files failed[/bold red]",
                    border_style="red", padding=(1, 2),
                )
            )
            sys.exit(1)

    # ===========================================================================
    # push  — two-phase upload with OCC conflict detection
    # ===========================================================================

    def push(self, file_path: str) -> None:
        """
        Upload a local file to the remote workspace.

        Uses Optimistic Concurrency Control (OCC): the client sends its
        `base_version` (last known server version).  If the server's current
        version is higher, it returns HTTP 409 — the user must pull first.
        """
        self._require_workspace()

        local_path = Path(file_path)
        if not local_path.exists():
            console.print(
                Panel(f"[bold]{file_path}[/bold] does not exist.",
                      title="[bold red]✗ File not found[/bold red]",
                      border_style="red", padding=(1, 2))
            )
            sys.exit(1)

        with console.status(f"[blue]Hashing [bold]{file_path}[/bold]…[/blue]", spinner="dots"):
            checksum = sha256_file(local_path)
            size     = local_path.stat().st_size

        manifest     = load_manifest()
        base_version = manifest.get(file_path, {}).get("version", 0)

        # ── Step 1: request upload slot ───────────────────────────────────
        with console.status("[blue]Requesting upload slot…[/blue]", spinner="dots"):
            try:
                req = self.session.post(
                    f"{self.base_url}/sync/upload-request",
                    json={
                        "workspace_token": self.token,
                        "file_path":       file_path,
                        "checksum":        checksum,
                        "size_bytes":      size,
                        "base_version":    base_version,
                    },
                    timeout=30,
                )
                self._raise_for_status(req)

            except HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 409:
                    # ── OCC conflict: server has a newer version ──────────
                    try:
                        remote_ver = exc.response.json().get("detail", "")
                    except Exception:
                        remote_ver = ""
                    console.print(
                        Panel(
                            f"[bold]{file_path}[/bold] has been updated on the server "
                            f"since your last pull.\n\n"
                            f"Your local base version : [cyan]{base_version}[/cyan]\n"
                            f"Run [cyan]study pull[/cyan] to get the latest version, "
                            f"then push again.",
                            title="[bold red]✗ Conflict — pull required[/bold red]",
                            border_style="red", padding=(1, 2),
                        )
                    )
                else:
                    console.print(
                        Panel(str(exc),
                              title="[bold red]✗ Upload request failed[/bold red]",
                              border_style="red", padding=(1, 2))
                    )
                sys.exit(1)
            except requests.ConnectionError as exc:
                console.print(
                    Panel(str(exc),
                          title="[bold red]✗ Connection error[/bold red]",
                          border_style="red", padding=(1, 2))
                )
                sys.exit(1)

        data         = req.json()
        presigned_url = data["presigned_url"]
        upload_id    = data["upload_id"]
        new_version  = data["new_version"]

        # ── Step 2: PUT bytes to mock-S3 ─────────────────────────────────
        progress = Progress(
            TextColumn("[bold blue]{task.fields[filename]}"),
            BarColumn(), DownloadColumn(),
            TransferSpeedColumn(), TimeRemainingColumn(),
            console=console,
        )
        with progress:
            task_id = progress.add_task("upload", filename=local_path.name, total=size)
            with _ProgressReader(local_path, task_id, progress) as reader:
                try:
                    put = requests.put(
                        presigned_url,
                        data=reader,
                        headers={"Content-Length": str(size)},
                        timeout=300,
                    )
                    put.raise_for_status()
                except Exception as exc:
                    console.print(
                        Panel(str(exc),
                              title="[bold red]✗ Upload failed[/bold red]",
                              border_style="red", padding=(1, 2))
                    )
                    sys.exit(1)

        # ── Step 3: commit ────────────────────────────────────────────────
        with console.status("[blue]Committing…[/blue]", spinner="dots"):
            try:
                commit = self.session.post(
                    f"{self.base_url}/sync/commit-upload",
                    json={"upload_id": upload_id},
                    timeout=30,
                )
                self._raise_for_status(commit)
            except (HTTPError, requests.ConnectionError) as exc:
                console.print(
                    Panel(str(exc),
                          title="[bold red]✗ Commit failed[/bold red]",
                          border_style="red", padding=(1, 2))
                )
                sys.exit(1)

        # Update vault + manifest
        vault_path = local_file_path(self.workspace_name, file_path)
        vault_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(local_path, vault_path)
        update_manifest_entry(file_path, new_version, checksum)

        console.print(
            Panel(
                f"[bold]{file_path}[/bold]\n"
                f"Version  [cyan]v{new_version}[/cyan]   "
                f"SHA-256  [dim]{checksum[:16]}…[/dim]   "
                f"Size  [dim]{size:,} B[/dim]",
                title="[bold green]✓ Push complete[/bold green]",
                border_style="green", padding=(1, 2),
            )
        )

    # ===========================================================================
    # status  — shows both local and server state
    # ===========================================================================

    def status(self) -> None:
        """
        Compare the remote workspace against local state and display a table.

        Fetches the server's file list so that files pushed by other users
        show up immediately — even before a pull.

        Status values
        -------------
        SYNCED    on disk and matching the server version
        MODIFIED  on disk but changed since the last push/pull
        NOT PULLED exists on server, not yet downloaded
        MISSING   in manifest but physically deleted from disk
        LOCAL     on disk but never pushed (untracked)
        """
        self._require_workspace()

        # Fetch server state so we can show files pushed by other users
        with console.status("[blue]Fetching server state…[/blue]", spinner="dots"):
            try:
                resp = self.session.get(
                    f"{self.base_url}/sync/state/{self.token}",
                    timeout=15,
                )
                self._raise_for_status(resp)
                remote_files = {
                    f["file_path"]: f
                    for f in resp.json().get("files", [])
                }
            except (HTTPError, requests.ConnectionError):
                remote_files = {}
                console.print(
                    "[yellow]⚠ Could not reach server — showing local state only.[/yellow]"
                )

        manifest = load_manifest()
        cwd      = Path(os.getcwd())

        # Collect every file path we know about from any source
        all_paths: set[str] = set()
        all_paths.update(remote_files.keys())
        all_paths.update(manifest.keys())
        # Add untracked files in cwd (skip hidden directories)
        for p in cwd.rglob("*"):
            if p.is_file() and not any(part.startswith(".") for part in p.parts):
                all_paths.add(str(p.relative_to(cwd)).replace("\\", "/"))

        if not all_paths:
            console.print(
                "[dim]No files yet.  Run [cyan]study push <file>[/cyan] to get started.[/dim]"
            )
            return

        table = Table(
            title=f"Workspace: [bold]{self.workspace_name}[/bold]",
            show_lines=False, show_header=True,
        )
        table.add_column("File",         style="bold", no_wrap=True)
        table.add_column("Status",       justify="center")
        table.add_column("Local ver",    justify="right", style="dim")
        table.add_column("Server ver",   justify="right", style="dim")

        for fp in sorted(all_paths):
            local_entry  = manifest.get(fp, {})
            local_ver    = local_entry.get("version", 0)
            local_cksum  = local_entry.get("checksum", "")
            remote_info  = remote_files.get(fp)
            remote_ver   = remote_info["latest_version"] if remote_info else None
            file_on_disk = (cwd / fp).exists()

            if remote_info and not file_on_disk and not local_entry:
                # Other user pushed this; we've never seen it
                status_cell  = "[cyan]NOT PULLED[/cyan]"
                l_ver_str    = "—"
                r_ver_str    = f"v{remote_ver}"

            elif remote_info and not file_on_disk and local_entry:
                # Was here, now gone from disk
                status_cell  = "[red]MISSING[/red]"
                l_ver_str    = f"v{local_ver}"
                r_ver_str    = f"v{remote_ver}"

            elif remote_info and file_on_disk:
                disk_cksum = sha256_file(cwd / fp)
                if disk_cksum == remote_info.get("latest_checksum", ""):
                    status_cell = "[green]SYNCED[/green]"
                elif disk_cksum == local_cksum:
                    # Disk matches our last push but server moved ahead
                    status_cell = "[cyan]NOT PULLED[/cyan]"
                else:
                    status_cell = "[yellow]MODIFIED[/yellow]"
                l_ver_str = f"v{local_ver}" if local_ver else "—"
                r_ver_str = f"v{remote_ver}"

            elif not remote_info and file_on_disk:
                # Local file not known to server
                status_cell  = "[dim]LOCAL[/dim]"
                l_ver_str    = "—"
                r_ver_str    = "—"

            else:
                continue  # ghost entry, skip

            table.add_row(fp, status_cell, l_ver_str, r_ver_str)

        console.print(table)
        console.print(
            "[dim]"
            "[green]SYNCED[/green]=up to date  "
            "[yellow]MODIFIED[/yellow]=local changes  "
            "[cyan]NOT PULLED[/cyan]=pull to get  "
            "[red]MISSING[/red]=deleted locally  "
            "[dim]LOCAL[/dim]=not yet pushed"
            "[/dim]"
        )
