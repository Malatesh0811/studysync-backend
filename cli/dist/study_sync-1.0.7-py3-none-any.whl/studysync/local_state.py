"""
local_state.py — Manages all local CLI state.

Directory layout
----------------
~/.study/
    config.json          — active workspace credentials
    manifest.json        — per-file {version, checksum} map
    workspaces/
        <workspace_name>/   — vault: local copies of synced files
"""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Directory constants
# ---------------------------------------------------------------------------

STUDY_DIR: Path = Path.home() / ".study"
WORKSPACES_DIR: Path = STUDY_DIR / "workspaces"
CONFIG_PATH: Path = STUDY_DIR / "config.json"
MANIFEST_PATH: Path = STUDY_DIR / "manifest.json"


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

def ensure_dirs() -> None:
    """Create ~/.study and ~/.study/workspaces/ if they don't exist."""
    STUDY_DIR.mkdir(parents=True, exist_ok=True)
    WORKSPACES_DIR.mkdir(parents=True, exist_ok=True)


def workspace_root(workspace_name: str) -> Path:
    """Return (and create) ~/.study/workspaces/<workspace_name>/."""
    p = WORKSPACES_DIR / workspace_name
    p.mkdir(parents=True, exist_ok=True)
    return p


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config() -> dict[str, Any]:
    """Load ~/.study/config.json; returns {} if missing or corrupt."""
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(data: dict[str, Any]) -> None:
    """Persist config to ~/.study/config.json."""
    ensure_dirs()
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Manifest
# ---------------------------------------------------------------------------

def load_manifest() -> dict[str, dict[str, Any]]:
    """
    Load ~/.study/manifest.json.

    Schema: {file_path: {version: int, checksum: str}}
    """
    if not MANIFEST_PATH.exists():
        return {}
    try:
        return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_manifest(data: dict[str, dict[str, Any]]) -> None:
    """Persist manifest to ~/.study/manifest.json."""
    ensure_dirs()
    MANIFEST_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def update_manifest_entry(file_path: str, version: int, checksum: str) -> None:
    """Update a single entry in the manifest without touching others."""
    manifest = load_manifest()
    manifest[file_path] = {"version": version, "checksum": checksum}
    save_manifest(manifest)


# ---------------------------------------------------------------------------
# Vault helpers
# ---------------------------------------------------------------------------

def local_file_path(workspace_name: str, file_path: str) -> Path:
    """Return the vault path for a given workspace file."""
    return WORKSPACES_DIR / workspace_name / file_path


def all_local_files(workspace_name: str) -> list[Path]:
    """
    Return every file currently in the vault for this workspace.
    Paths are relative to the vault root.
    """
    root = WORKSPACES_DIR / workspace_name
    if not root.exists():
        return []
    return [p for p in root.rglob("*") if p.is_file()]


# ---------------------------------------------------------------------------
# Hashing
# ---------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    """Return the hex SHA-256 digest of *path* using 64 KiB streaming reads."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65_536), b""):
            h.update(chunk)
    return h.hexdigest()
