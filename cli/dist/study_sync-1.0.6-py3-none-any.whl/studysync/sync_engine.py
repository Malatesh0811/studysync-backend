"""
sync_engine.py — Core networking and sync logic for StudySync CLI.

Two-phase upload
----------------
1. POST /upload-request  → {presigned_put_url, pending_upload_id}
2. PUT presigned_put_url (raw bytes)
3. POST /commit-upload   → updated file record

Optimistic concurrency control
-------------------------------
Every push includes base_version.  If that doesn't match the server's
latest_version the server returns HTTP 409.  The client must pull first.

Alias resolution
-----------------
Users can join with a short workspace alias (name) instead of a raw UUID.
SyncEngine.resolve_alias() calls GET /alias/{alias} on the backend, which
returns the workspace's access_token.
"""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path
from typing import Any

import requests
from requests import HTTPError, Session
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table

from .constants import PRODUCTION_SERVER_URL
from .local_state import (
    all_local_files,
    ensure_dirs,
    load_config,
    load_manifest,
    local_file_path,
    save_manifest,
    sha256_file,
    update_manifest_entry,
    workspace_root,
    WORKSPACES_DIR,
)

console = Console()

# ---------------------------------------------------------------------------
# Progress-aware file reader
# ---------------------------------------------------------------------------

class _ProgressReader:
    """Wrap a file so requests streams it while updating a Rich progress bar."""

    def __init__(self, path: Path, task_id: Any, progress: Progress) -> None:
        self._fh = open(path, "rb")
        self._task_id = task_id
        self._progress = progress
        self._size = path.stat().st_size

    def read(self, size: int = -1) -> bytes:
        chunk = self._fh.read(size)
        if chunk:
            self._progress.update(self._task_id, advance=len(chunk))
        return chunk

    def __len__(self) -> int:
        return self._size

    def close(self) -> None:
        self._fh.close()

    def __enter__(self) -> "_ProgressReader":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# SyncEngine
# ---------------------------------------------------------------------------

class SyncEngine:
    """Handles all communication with the StudySync backend."""

    def __init__(self, server_url: str | None = None) -> None:
        ensure_dirs()
        config = load_config()
        raw_url = server_url or config.get("server_url", PRODUCTION_SERVER_URL)
        self.base_url: str = raw_url.rstrip("/")
        self.workspace_id: str = config.get("workspace_id", "")
        self.workspace_name: str = config.get("workspace_name", "")
        self.token: str = config.get("workspace_token", "")

        self.session: Session = requests.Session()
        if self.token:
            self.session.headers["Authorization"] = f"Bearer {self.token}"
        self.session.headers["User-Agent"] = "studysync-cli/1.0"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _raise_for_status(self, resp: requests.Response) -> None:
        """Raise HTTPError with the backend's JSON detail if present."""
        if resp.ok:
            return
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise HTTPError(
            f"HTTP {resp.status_code}: {detail}",
            response=resp,
        )

    def _require_workspace(self) -> None:
        """Abort with a friendly message if no workspace is configured."""
        if not self.workspace_id or not self.token:
            console.print(
                Panel(
                    "No workspace is configured.\n\n"
                    "Create one:  [cyan]study workspace create <name>[/cyan]\n"
                    "Or join one: [cyan]study join <token-or-alias>[/cyan]",
                    title="[bold red]✗ Not configured[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    # ------------------------------------------------------------------
    # Workspace management
    # ------------------------------------------------------------------

    def create_workspace(self, name: str) -> dict[str, Any]:
        """POST /workspaces — create a new workspace; returns {workspace_id, access_token, name}."""
        resp = self.session.post(
            f"{self.base_url}/workspaces",
            json={"name": name},
            timeout=30,
        )
        self._raise_for_status(resp)
        data = resp.json()
        return {
            "workspace_id": data["workspace_id"],
            "access_token": data["access_token"],
            "name": data["name"],
        }

    def join_workspace(self, token: str) -> dict[str, Any]:
        """GET /workspaces/{token} — validate token; returns {workspace_id, name}."""
        resp = self.session.get(
            f"{self.base_url}/workspaces/{token}",
            timeout=30,
        )
        self._raise_for_status(resp)
        data = resp.json()
        return {
            "workspace_id": data["workspace_id"],
            "name": data["name"],
        }

    def resolve_input(self, token_or_alias: str) -> dict:
        """
        GET /resolve/{input} — resolve a token or alias to workspace info.

        The backend checks its Aliases table first.  If the input is not a
        known alias it tries to interpret it as a raw UUID access_token.

        Returns
        -------
        dict
            Keys: ``resolved_from_alias`` (bool), ``alias`` (str | None),
            ``workspace_id``, ``name``, ``access_token``.

        Raises
        ------
        SystemExit
            Prints a red error panel and exits 1 on HTTP 404 or connection
            failure.
        """
        try:
            resp = self.session.get(
                f"{self.base_url}/resolve/{token_or_alias}",
                timeout=15,
            )
            self._raise_for_status(resp)
            return resp.json()
        except HTTPError as exc:
            code = exc.response.status_code if exc.response is not None else "?"
            try:
                detail = exc.response.json().get("detail", str(exc))
            except Exception:
                detail = str(exc)
            console.print(
                Panel(
                    f"{detail}",
                    title=f"[bold red]✗ Could not resolve '{token_or_alias}'[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)
        except requests.ConnectionError:
            console.print(
                Panel(
                    f"Could not reach [cyan]{self.base_url}[/cyan].\n"
                    "Check your network connection or --server URL.",
                    title="[bold red]✗ Connection error[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    # ------------------------------------------------------------------
    # Pull
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Pull helpers
    # ------------------------------------------------------------------

    class _FileStatus:
        """Categorises why a remote file needs to be (re-)downloaded."""
        NEW        = "new"          # never seen locally
        UPDATE     = "update"       # server version is newer
        MISSING    = "missing"      # in manifest but absent from disk
        DRIFTED    = "drifted"      # on disk + manifest, but checksum mismatch
        OK         = "ok"           # fully in sync

    def _deep_scan(
        self,
        manifest: dict,
        cwd: "Path",
    ) -> dict[str, dict]:
        """
        Build a ground-truth view of every file that either the manifest
        or the local directory knows about.

        Returns
        -------
        dict  keyed by relative file path, values:
            exists   bool   — file is physically present on disk
            version  int    — version recorded in manifest (0 if unknown)
            m_checksum str  — checksum recorded in manifest ('' if unknown)
            d_checksum str  — actual SHA-256 of the file on disk ('' if absent)
        """
        result: dict[str, dict] = {}

        # Seed from manifest
        for fp, entry in manifest.items():
            disk_path = cwd / fp
            exists    = disk_path.exists() and disk_path.is_file()
            result[fp] = {
                "exists":     exists,
                "version":    entry.get("version", 0),
                "m_checksum": entry.get("checksum", ""),
                "d_checksum": sha256_file(disk_path) if exists else "",
            }

        # Also pick up untracked files that happen to sit in cwd
        # (they won't be downloaded, but we use this for status display)
        for disk_path in cwd.rglob("*"):
            if not disk_path.is_file():
                continue
            rel = str(disk_path.relative_to(cwd)).replace("\\", "/")
            # Skip hidden dirs (e.g. .studysync, .git)
            if any(part.startswith(".") for part in disk_path.parts):
                continue
            if rel not in result:
                result[rel] = {
                    "exists":     True,
                    "version":    0,
                    "m_checksum": "",
                    "d_checksum": sha256_file(disk_path),
                }

        return result

    def _classify(
        self,
        rf: dict,
        local: dict | None,
    ) -> str:
        """
        Classify a single remote file against local ground truth.

        Parameters
        ----------
        rf    Remote file dict from /sync/state (file_path, latest_version,
              latest_checksum, …).
        local Ground-truth dict from _deep_scan, or None if file is unknown.

        Returns one of _FileStatus constants.
        """
        if local is None or local["version"] == 0 and not local["exists"]:
            return self._FileStatus.NEW

        if not local["exists"]:
            return self._FileStatus.MISSING

        remote_ver = rf["latest_version"]
        local_ver  = local["version"]

        if remote_ver > local_ver:
            return self._FileStatus.UPDATE

        # Same version — verify the bytes on disk match what the server recorded
        if local["d_checksum"] and local["d_checksum"] != rf["latest_checksum"]:
            return self._FileStatus.DRIFTED

        return self._FileStatus.OK

    # ------------------------------------------------------------------
    # Pull
    # ------------------------------------------------------------------

    def pull(self) -> None:
        """
        Self-healing pull — always converges local state to the server truth.

        Algorithm
        ---------
        1. Fetch the remote workspace file list from the server.
        2. Deep-scan the local directory: for every file the manifest knows
           about, confirm it physically exists and hash it.
        3. Classify each remote file into one of:
             NEW      — never seen locally
             UPDATE   — server has a higher version number
             MISSING  — manifest says it exists, but the file is gone from disk
             DRIFTED  — version matches but on-disk checksum ≠ server checksum
                        (handles corrupted files and manifest corruption)
             OK       — fully in sync, skip
        4. Download every non-OK file unconditionally.
        5. Repair the manifest: update entries for downloaded files and prune
           entries for files that no longer exist on the server.

        The user never has to delete hidden folders.
        """
        self._require_workspace()

        # ── 1. Fetch remote state ─────────────────────────────────────────
        with console.status("[blue]Fetching remote workspace state…[/blue]", spinner="dots"):
            try:
                resp = self.session.get(
                    f"{self.base_url}/sync/state/{self.token}",
                    timeout=30,
                )
                self._raise_for_status(resp)
            except (HTTPError, requests.ConnectionError) as exc:
                console.print(
                    Panel(
                        str(exc),
                        title="[bold red]✗ Pull failed — cannot reach server[/bold red]",
                        border_style="red",
                        padding=(1, 2),
                    )
                )
                sys.exit(1)

        remote_files: list[dict] = resp.json().get("files", [])

        if not remote_files:
            console.print("[dim]Remote workspace is empty — nothing to pull.[/dim]")
            return

        # ── 2. Deep-scan local state ──────────────────────────────────────
        manifest  = load_manifest()
        cwd       = Path(os.getcwd())

        with console.status("[blue]Scanning local files…[/blue]", spinner="dots"):
            local_state = self._deep_scan(manifest, cwd)

        # ── 3. Classify each remote file ──────────────────────────────────
        remote_by_path = {rf["file_path"]: rf for rf in remote_files}

        plan: list[tuple[dict, str]] = []   # (remote_file_dict, status)
        for rf in remote_files:
            status = self._classify(rf, local_state.get(rf["file_path"]))
            if status != self._FileStatus.OK:
                plan.append((rf, status))

        # ── Show pre-download summary ─────────────────────────────────────
        if not plan:
            console.print(
                Panel(
                    "All [bold]{count}[/bold] file(s) verified — "
                    "local checksums match the server.".format(count=len(remote_files)),
                    title="[bold green]✓ Already in sync[/bold green]",
                    border_style="green",
                    padding=(0, 2),
                )
            )
            return

        # Print a heal-plan table so the user can see exactly what will happen
        from rich.table import Table as _Table
        from rich import box as _box
        plan_tbl = _Table(box=_box.SIMPLE, show_header=True,
                          header_style="bold blue", padding=(0, 2))
        plan_tbl.add_column("File",   style="bold")
        plan_tbl.add_column("Reason", justify="left")

        _status_label = {
            self._FileStatus.NEW:     "[cyan]new file[/cyan]",
            self._FileStatus.UPDATE:  "[blue]server update[/blue]",
            self._FileStatus.MISSING: "[yellow]missing from disk[/yellow]",
            self._FileStatus.DRIFTED: "[magenta]checksum drift — healing[/magenta]",
        }
        for rf, st in plan:
            fp       = rf["file_path"]
            lo       = local_state.get(fp, {})
            detail   = _status_label.get(st, st)
            if st == self._FileStatus.UPDATE:
                lv = lo.get("version", 0)
                rv = rf["latest_version"]
                detail += f" (local v{lv} → server v{rv})"
            elif st == self._FileStatus.DRIFTED:
                lc = lo.get("d_checksum", "")[:8]
                rc = (rf.get("latest_checksum") or "")[:8]
                detail += f" (disk {lc}… ≠ server {rc}…)"
            plan_tbl.add_row(fp, detail)

        from rich.rule import Rule as _Rule
        console.print(_Rule("[bold]Sync plan[/bold]", style="dim"))
        console.print(plan_tbl)

        # ── 4. Download every non-OK file ─────────────────────────────────
        updated:  list[tuple[str, str]] = []   # (file_path, status)
        errors:   list[str]             = []

        progress = Progress(
            TextColumn("[bold blue]{task.fields[filename]}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        )

        with progress:
            for rf, st in plan:
                fp:       str  = rf["file_path"]
                version:  int  = rf["latest_version"]
                checksum: str  = rf.get("latest_checksum") or ""
                size:     int  = rf.get("size_bytes") or 0

                task_id = progress.add_task(
                    "download",
                    filename=fp,
                    total=size if size > 0 else None,
                )

                # Request a presigned GET URL
                try:
                    dl_resp = self.session.get(
                        f"{self.base_url}/sync/download-request",
                        params={"workspace_token": self.token, "file_path": fp},
                        timeout=30,
                    )
                    self._raise_for_status(dl_resp)
                except (HTTPError, requests.ConnectionError) as exc:
                    errors.append(f"{fp}: {exc}")
                    progress.update(task_id, visible=False)
                    continue

                presigned_url = dl_resp.json()["presigned_url"]

                # Stream to vault (hidden copy)
                vault_path = local_file_path(self.workspace_name, fp)
                vault_path.parent.mkdir(parents=True, exist_ok=True)

                try:
                    with requests.get(presigned_url, stream=True, timeout=120) as dr:
                        self._raise_for_status(dr)
                        with open(vault_path, "wb") as out:
                            for chunk in dr.iter_content(chunk_size=65_536):
                                out.write(chunk)
                                progress.update(task_id, advance=len(chunk))
                except Exception as exc:
                    errors.append(f"{fp}: download failed — {exc}")
                    progress.update(task_id, visible=False)
                    continue

                # ── Verify checksum (guards against corrupt transfer) ─────
                actual_checksum = sha256_file(vault_path)
                if actual_checksum != checksum:
                    errors.append(
                        f"{fp}: checksum mismatch after download "
                        f"(expected {checksum[:8]}…, got {actual_checksum[:8]}…). "
                        f"File not written to disk."
                    )
                    vault_path.unlink(missing_ok=True)
                    progress.update(task_id, visible=False)
                    continue

                # ── Checkout: copy verified file to cwd ───────────────────
                checkout_dest = cwd / fp
                checkout_dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(vault_path, checkout_dest)

                # ── Update manifest ───────────────────────────────────────
                update_manifest_entry(fp, version, checksum)
                updated.append((fp, st))

        # ── 5. Prune stale manifest entries (files deleted from server) ───
        stale = set(manifest.keys()) - set(remote_by_path.keys())
        if stale:
            live_manifest = load_manifest()
            for fp in stale:
                live_manifest.pop(fp, None)
            save_manifest(live_manifest)
            console.print(
                f"[dim]Pruned {len(stale)} stale manifest "
                f"entr{'y' if len(stale)==1 else 'ies'}: "
                + ", ".join(sorted(stale)) + "[/dim]"
            )

        # ── Report ────────────────────────────────────────────────────────
        _icon = {
            self._FileStatus.NEW:     "[green]+[/green]",
            self._FileStatus.UPDATE:  "[blue]↑[/blue]",
            self._FileStatus.MISSING: "[yellow]⚕[/yellow]",
            self._FileStatus.DRIFTED: "[magenta]⚕[/magenta]",
        }
        if updated:
            lines = "\n".join(
                f"  {_icon.get(st, '✓')} {fp}"
                for fp, st in updated
            )
            healed = [fp for fp, st in updated
                      if st in (self._FileStatus.MISSING, self._FileStatus.DRIFTED)]
            title = (
                f"[bold green]✓ Synced {len(updated)} file(s)"
                + (f" — {len(healed)} healed" if healed else "")
                + "[/bold green]"
            )
            console.print(Panel(lines, title=title, border_style="green", padding=(1, 2)))

        if errors:
            err_lines = "\n".join(f"  [red]✗[/red] {e}" for e in errors)
            console.print(
                Panel(
                    err_lines,
                    title="[bold red]✗ Some files could not be synced[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    def push(self, file_path: str) -> None:
        """Upload *file_path* to the remote workspace."""
        self._require_workspace()

        local_path = Path(file_path)
        if not local_path.exists():
            console.print(
                Panel(
                    f"[bold]{file_path}[/bold] does not exist.",
                    title="[bold red]✗ File not found[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

        with console.status(
            f"[blue]Hashing [bold]{file_path}[/bold]…[/blue]", spinner="dots"
        ):
            checksum = sha256_file(local_path)
            size = local_path.stat().st_size

        manifest = load_manifest()
        base_version = manifest.get(file_path, {}).get("version", 0)

        # ── Step 1: upload-request ──────────────────────────────────────────
        with console.status("[blue]Requesting upload slot…[/blue]", spinner="dots"):
            try:
                req_resp = self.session.post(
                    f"{self.base_url}/sync/upload-request",
                    json={
                        "workspace_token": self.token,
                        "file_path":       file_path,
                        "checksum":        checksum,
                        "size_bytes":      size,
                        "base_version":    base_version,
                    },
                    timeout=30,
                )
                self._raise_for_status(req_resp)
            except HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 409:
                    console.print(
                        Panel(
                            f"[bold]{file_path}[/bold] was modified on the server since your "
                            f"last pull (local base version: {base_version}).\n\n"
                            "Run [cyan]study pull[/cyan] to sync, then push again.",
                            title="[bold red]✗ Conflict (HTTP 409)[/bold red]",
                            border_style="red",
                            padding=(1, 2),
                        )
                    )
                else:
                    console.print(
                        Panel(
                            str(exc),
                            title="[bold red]✗ Upload request failed[/bold red]",
                            border_style="red",
                            padding=(1, 2),
                        )
                    )
                sys.exit(1)
            except requests.ConnectionError as exc:
                console.print(
                    Panel(
                        str(exc),
                        title="[bold red]✗ Connection error[/bold red]",
                        border_style="red",
                        padding=(1, 2),
                    )
                )
                sys.exit(1)

        upload_data  = req_resp.json()
        presigned_url = upload_data["presigned_url"]
        upload_id    = upload_data["upload_id"]
        new_version  = upload_data["new_version"]

        # ── Step 2: PUT to mock-S3 with progress bar ────────────────────────
        progress = Progress(
            TextColumn("[bold blue]{task.fields[filename]}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        )

        with progress:
            task_id = progress.add_task("upload", filename=local_path.name, total=size)
            with _ProgressReader(local_path, task_id, progress) as reader:
                try:
                    put_resp = requests.put(
                        presigned_url,
                        data=reader,
                        headers={"Content-Length": str(size)},
                        timeout=300,
                    )
                    put_resp.raise_for_status()
                except Exception as exc:
                    console.print(
                        Panel(
                            str(exc),
                            title="[bold red]✗ Upload to server failed[/bold red]",
                            border_style="red",
                            padding=(1, 2),
                        )
                    )
                    sys.exit(1)

        # ── Step 3: commit-upload ───────────────────────────────────────────
        with console.status("[blue]Committing…[/blue]", spinner="dots"):
            try:
                commit_resp = self.session.post(
                    f"{self.base_url}/sync/commit-upload",
                    json={"upload_id": upload_id},
                    timeout=30,
                )
                self._raise_for_status(commit_resp)
            except (HTTPError, requests.ConnectionError) as exc:
                console.print(
                    Panel(
                        str(exc),
                        title="[bold red]✗ Commit failed[/bold red]",
                        border_style="red",
                        padding=(1, 2),
                    )
                )
                sys.exit(1)

        # Update local vault + manifest
        vault_path = local_file_path(self.workspace_name, file_path)
        vault_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(local_path, vault_path)
        update_manifest_entry(file_path, new_version, checksum)

        console.print(
            Panel(
                f"[bold]{file_path}[/bold]\n"
                f"Version  [cyan]{new_version}[/cyan]   "
                f"SHA-256  [dim]{checksum[:16]}…[/dim]   "
                f"Size  [dim]{size:,} B[/dim]",
                title="[bold green]✓ Push complete[/bold green]",
                border_style="green",
                padding=(1, 2),
            )
        )

    def status(self) -> None:
        """Print a Rich table showing the sync state of every tracked file."""
        self._require_workspace()

        manifest = load_manifest()
        vault_files = {
            str(p.relative_to(WORKSPACES_DIR / self.workspace_name))
            for p in all_local_files(self.workspace_name)
        }
        all_keys = set(manifest.keys()) | vault_files

        if not all_keys:
            console.print("[dim]No tracked files yet.  Run [cyan]study push <file>[/cyan] to start.[/dim]")
            return

        table = Table(title=f"Workspace: {self.workspace_name}", show_lines=False)
        table.add_column("File", style="bold", no_wrap=True)
        table.add_column("Status", justify="center")
        table.add_column("Version", justify="right")
        table.add_column("Checksum", style="dim")

        cwd = Path(os.getcwd())

        for fp in sorted(all_keys):
            entry = manifest.get(fp, {})
            m_version = entry.get("version", "—")
            m_checksum = entry.get("checksum", "")

            cwd_path = cwd / fp

            if fp not in manifest:
                status_cell = "[blue]UNTRACKED[/blue]"
                checksum_display = "—"
                version_display = "—"
            elif not cwd_path.exists():
                status_cell = "[red]DELETED[/red]"
                checksum_display = m_checksum[:12] + "…" if m_checksum else "—"
                version_display = str(m_version)
            else:
                current_checksum = sha256_file(cwd_path)
                if current_checksum == m_checksum:
                    status_cell = "[green]CLEAN[/green]"
                else:
                    status_cell = "[yellow]MODIFIED[/yellow]"
                checksum_display = current_checksum[:12] + "…"
                version_display = str(m_version)

            table.add_row(fp, status_cell, version_display, checksum_display)

        console.print(table)
