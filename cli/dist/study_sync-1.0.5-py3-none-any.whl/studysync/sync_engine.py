"""
sync_engine.py — Core networking and sync logic for StudySync CLI.

Two-phase upload
----------------
1. POST /upload-request  → {presigned_put_url, pending_upload_id}
2. PUT presigned_put_url (raw bytes)
3. POST /commit-upload   → updated file record

Optimistic concurrency control
-------------------------------
Every push includes base_version.  If that doesn't match the server's
latest_version the server returns HTTP 409.  The client must pull first.

Alias resolution
-----------------
Users can join with a short workspace alias (name) instead of a raw UUID.
SyncEngine.resolve_alias() calls GET /alias/{alias} on the backend, which
returns the workspace's access_token.
"""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path
from typing import Any

import requests
from requests import HTTPError, Session
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table

from .constants import PRODUCTION_SERVER_URL
from .local_state import (
    all_local_files,
    ensure_dirs,
    load_config,
    load_manifest,
    local_file_path,
    save_manifest,
    sha256_file,
    update_manifest_entry,
    workspace_root,
    WORKSPACES_DIR,
)

console = Console()

# ---------------------------------------------------------------------------
# Progress-aware file reader
# ---------------------------------------------------------------------------

class _ProgressReader:
    """Wrap a file so requests streams it while updating a Rich progress bar."""

    def __init__(self, path: Path, task_id: Any, progress: Progress) -> None:
        self._fh = open(path, "rb")
        self._task_id = task_id
        self._progress = progress
        self._size = path.stat().st_size

    def read(self, size: int = -1) -> bytes:
        chunk = self._fh.read(size)
        if chunk:
            self._progress.update(self._task_id, advance=len(chunk))
        return chunk

    def __len__(self) -> int:
        return self._size

    def close(self) -> None:
        self._fh.close()

    def __enter__(self) -> "_ProgressReader":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# SyncEngine
# ---------------------------------------------------------------------------

class SyncEngine:
    """Handles all communication with the StudySync backend."""

    def __init__(self, server_url: str | None = None) -> None:
        ensure_dirs()
        config = load_config()
        raw_url = server_url or config.get("server_url", PRODUCTION_SERVER_URL)
        self.base_url: str = raw_url.rstrip("/")
        self.workspace_id: str = config.get("workspace_id", "")
        self.workspace_name: str = config.get("workspace_name", "")
        self.token: str = config.get("workspace_token", "")

        self.session: Session = requests.Session()
        if self.token:
            self.session.headers["Authorization"] = f"Bearer {self.token}"
        self.session.headers["User-Agent"] = "studysync-cli/1.0"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _raise_for_status(self, resp: requests.Response) -> None:
        """Raise HTTPError with the backend's JSON detail if present."""
        if resp.ok:
            return
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise HTTPError(
            f"HTTP {resp.status_code}: {detail}",
            response=resp,
        )

    def _require_workspace(self) -> None:
        """Abort with a friendly message if no workspace is configured."""
        if not self.workspace_id or not self.token:
            console.print(
                Panel(
                    "No workspace is configured.\n\n"
                    "Create one:  [cyan]study workspace create <name>[/cyan]\n"
                    "Or join one: [cyan]study join <token-or-alias>[/cyan]",
                    title="[bold red]✗ Not configured[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    # ------------------------------------------------------------------
    # Workspace management
    # ------------------------------------------------------------------

    def create_workspace(self, name: str) -> dict[str, Any]:
        """POST /workspaces — create a new workspace; returns {workspace_id, access_token, name}."""
        resp = self.session.post(
            f"{self.base_url}/workspaces",
            json={"name": name},
            timeout=30,
        )
        self._raise_for_status(resp)
        data = resp.json()
        return {
            "workspace_id": data["workspace_id"],
            "access_token": data["access_token"],
            "name": data["name"],
        }

    def join_workspace(self, token: str) -> dict[str, Any]:
        """GET /workspaces/{token} — validate token; returns {workspace_id, name}."""
        resp = self.session.get(
            f"{self.base_url}/workspaces/{token}",
            timeout=30,
        )
        self._raise_for_status(resp)
        data = resp.json()
        return {
            "workspace_id": data["workspace_id"],
            "name": data["name"],
        }

    def resolve_input(self, token_or_alias: str) -> dict:
        """
        GET /resolve/{input} — resolve a token or alias to workspace info.

        The backend checks its Aliases table first.  If the input is not a
        known alias it tries to interpret it as a raw UUID access_token.

        Returns
        -------
        dict
            Keys: ``resolved_from_alias`` (bool), ``alias`` (str | None),
            ``workspace_id``, ``name``, ``access_token``.

        Raises
        ------
        SystemExit
            Prints a red error panel and exits 1 on HTTP 404 or connection
            failure.
        """
        try:
            resp = self.session.get(
                f"{self.base_url}/resolve/{token_or_alias}",
                timeout=15,
            )
            self._raise_for_status(resp)
            return resp.json()
        except HTTPError as exc:
            code = exc.response.status_code if exc.response is not None else "?"
            try:
                detail = exc.response.json().get("detail", str(exc))
            except Exception:
                detail = str(exc)
            console.print(
                Panel(
                    f"{detail}",
                    title=f"[bold red]✗ Could not resolve '{token_or_alias}'[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)
        except requests.ConnectionError:
            console.print(
                Panel(
                    f"Could not reach [cyan]{self.base_url}[/cyan].\n"
                    "Check your network connection or --server URL.",
                    title="[bold red]✗ Connection error[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    # ------------------------------------------------------------------
    # Pull
    # ------------------------------------------------------------------

    def pull(self) -> None:
        """Download all new/changed files from the remote workspace."""
        self._require_workspace()

        # 1. Fetch remote file state
        with console.status("[blue]Fetching remote file list…[/blue]", spinner="dots"):
            try:
                resp = self.session.get(
                    f"{self.base_url}/sync/state/{self.token}",
                    timeout=30,
                )
                self._raise_for_status(resp)
            except (HTTPError, requests.ConnectionError) as exc:
                console.print(
                    Panel(
                        str(exc),
                        title="[bold red]✗ Pull failed[/bold red]",
                        border_style="red",
                        padding=(1, 2),
                    )
                )
                sys.exit(1)

        remote_files: list[dict] = resp.json().get("files", [])
        manifest = load_manifest()

        if not remote_files:
            console.print("[dim]No files in remote workspace.[/dim]")
            return

        # 2. Determine what to download
        to_download = [
            rf for rf in remote_files
            if manifest.get(rf["file_path"], {}).get("version", -1) < rf["latest_version"]
        ]

        if not to_download:
            console.print(
                Panel(
                    "Everything is up to date — no files to download.",
                    title="[bold green]✓ Already in sync[/bold green]",
                    border_style="green",
                    padding=(0, 2),
                )
            )
            return

        # 3. Download each file
        cwd = Path(os.getcwd())
        updated: list[str] = []
        errors: list[str] = []

        progress = Progress(
            TextColumn("[bold blue]{task.fields[filename]}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        )

        with progress:
            for rf in to_download:
                fp: str      = rf["file_path"]
                version: int = rf["latest_version"]
                checksum: str = rf["latest_checksum"]
                size: int    = rf.get("size_bytes") or 0

                task_id = progress.add_task(
                    "download",
                    filename=fp,
                    total=size if size > 0 else None,
                )

                # Request presigned GET URL  — GET /sync/download-request?...
                try:
                    dl_resp = self.session.get(
                        f"{self.base_url}/sync/download-request",
                        params={"workspace_token": self.token, "file_path": fp},
                        timeout=30,
                    )
                    self._raise_for_status(dl_resp)
                except (HTTPError, requests.ConnectionError) as exc:
                    errors.append(f"{fp}: {exc}")
                    progress.update(task_id, visible=False)
                    continue

                presigned_url = dl_resp.json()["presigned_url"]

                # Stream to vault
                vault_path = local_file_path(self.workspace_name, fp)
                vault_path.parent.mkdir(parents=True, exist_ok=True)

                try:
                    with requests.get(presigned_url, stream=True, timeout=120) as dr:
                        self._raise_for_status(dr)
                        with open(vault_path, "wb") as out:
                            for chunk in dr.iter_content(chunk_size=65_536):
                                out.write(chunk)
                                progress.update(task_id, advance=len(chunk))
                except Exception as exc:
                    errors.append(f"{fp}: {exc}")
                    progress.update(task_id, visible=False)
                    continue

                # Verify checksum
                actual = sha256_file(vault_path)
                if actual != checksum:
                    errors.append(
                        f"{fp}: checksum mismatch "
                        f"(expected {checksum[:8]}…, got {actual[:8]}…)"
                    )
                    continue

                # Checkout to cwd
                checkout_dest = cwd / fp
                checkout_dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(vault_path, checkout_dest)

                update_manifest_entry(fp, version, checksum)
                updated.append(fp)

        # 4. Report
        if updated:
            file_list = "\n".join(f"  [green]✓[/green] {f}" for f in updated)
            console.print(
                Panel(
                    file_list,
                    title=f"[bold green]✓ Pulled {len(updated)} file(s)[/bold green]",
                    border_style="green",
                    padding=(1, 2),
                )
            )
        if errors:
            err_list = "\n".join(f"  [red]✗[/red] {e}" for e in errors)
            console.print(
                Panel(
                    err_list,
                    title="[bold red]✗ Some files failed[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

    def push(self, file_path: str) -> None:
        """Upload *file_path* to the remote workspace."""
        self._require_workspace()

        local_path = Path(file_path)
        if not local_path.exists():
            console.print(
                Panel(
                    f"[bold]{file_path}[/bold] does not exist.",
                    title="[bold red]✗ File not found[/bold red]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            sys.exit(1)

        with console.status(
            f"[blue]Hashing [bold]{file_path}[/bold]…[/blue]", spinner="dots"
        ):
            checksum = sha256_file(local_path)
            size = local_path.stat().st_size

        manifest = load_manifest()
        base_version = manifest.get(file_path, {}).get("version", 0)

        # ── Step 1: upload-request ──────────────────────────────────────────
        with console.status("[blue]Requesting upload slot…[/blue]", spinner="dots"):
            try:
                req_resp = self.session.post(
                    f"{self.base_url}/sync/upload-request",
                    json={
                        "workspace_token": self.token,
                        "file_path":       file_path,
                        "checksum":        checksum,
                        "size_bytes":      size,
                        "base_version":    base_version,
                    },
                    timeout=30,
                )
                self._raise_for_status(req_resp)
            except HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 409:
                    console.print(
                        Panel(
                            f"[bold]{file_path}[/bold] was modified on the server since your "
                            f"last pull (local base version: {base_version}).\n\n"
                            "Run [cyan]study pull[/cyan] to sync, then push again.",
                            title="[bold red]✗ Conflict (HTTP 409)[/bold red]",
                            border_style="red",
                            padding=(1, 2),
                        )
                    )
                else:
                    console.print(
                        Panel(
                            str(exc),
                            title="[bold red]✗ Upload request failed[/bold red]",
                            border_style="red",
                            padding=(1, 2),
                        )
                    )
                sys.exit(1)
            except requests.ConnectionError as exc:
                console.print(
                    Panel(
                        str(exc),
                        title="[bold red]✗ Connection error[/bold red]",
                        border_style="red",
                        padding=(1, 2),
                    )
                )
                sys.exit(1)

        upload_data  = req_resp.json()
        presigned_url = upload_data["presigned_url"]
        upload_id    = upload_data["upload_id"]
        new_version  = upload_data["new_version"]

        # ── Step 2: PUT to mock-S3 with progress bar ────────────────────────
        progress = Progress(
            TextColumn("[bold blue]{task.fields[filename]}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        )

        with progress:
            task_id = progress.add_task("upload", filename=local_path.name, total=size)
            with _ProgressReader(local_path, task_id, progress) as reader:
                try:
                    put_resp = requests.put(
                        presigned_url,
                        data=reader,
                        headers={"Content-Length": str(size)},
                        timeout=300,
                    )
                    put_resp.raise_for_status()
                except Exception as exc:
                    console.print(
                        Panel(
                            str(exc),
                            title="[bold red]✗ Upload to server failed[/bold red]",
                            border_style="red",
                            padding=(1, 2),
                        )
                    )
                    sys.exit(1)

        # ── Step 3: commit-upload ───────────────────────────────────────────
        with console.status("[blue]Committing…[/blue]", spinner="dots"):
            try:
                commit_resp = self.session.post(
                    f"{self.base_url}/sync/commit-upload",
                    json={"upload_id": upload_id},
                    timeout=30,
                )
                self._raise_for_status(commit_resp)
            except (HTTPError, requests.ConnectionError) as exc:
                console.print(
                    Panel(
                        str(exc),
                        title="[bold red]✗ Commit failed[/bold red]",
                        border_style="red",
                        padding=(1, 2),
                    )
                )
                sys.exit(1)

        # Update local vault + manifest
        vault_path = local_file_path(self.workspace_name, file_path)
        vault_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(local_path, vault_path)
        update_manifest_entry(file_path, new_version, checksum)

        console.print(
            Panel(
                f"[bold]{file_path}[/bold]\n"
                f"Version  [cyan]{new_version}[/cyan]   "
                f"SHA-256  [dim]{checksum[:16]}…[/dim]   "
                f"Size  [dim]{size:,} B[/dim]",
                title="[bold green]✓ Push complete[/bold green]",
                border_style="green",
                padding=(1, 2),
            )
        )

    def status(self) -> None:
        """Print a Rich table showing the sync state of every tracked file."""
        self._require_workspace()

        manifest = load_manifest()
        vault_files = {
            str(p.relative_to(WORKSPACES_DIR / self.workspace_name))
            for p in all_local_files(self.workspace_name)
        }
        all_keys = set(manifest.keys()) | vault_files

        if not all_keys:
            console.print("[dim]No tracked files yet.  Run [cyan]study push <file>[/cyan] to start.[/dim]")
            return

        table = Table(title=f"Workspace: {self.workspace_name}", show_lines=False)
        table.add_column("File", style="bold", no_wrap=True)
        table.add_column("Status", justify="center")
        table.add_column("Version", justify="right")
        table.add_column("Checksum", style="dim")

        cwd = Path(os.getcwd())

        for fp in sorted(all_keys):
            entry = manifest.get(fp, {})
            m_version = entry.get("version", "—")
            m_checksum = entry.get("checksum", "")

            cwd_path = cwd / fp

            if fp not in manifest:
                status_cell = "[blue]UNTRACKED[/blue]"
                checksum_display = "—"
                version_display = "—"
            elif not cwd_path.exists():
                status_cell = "[red]DELETED[/red]"
                checksum_display = m_checksum[:12] + "…" if m_checksum else "—"
                version_display = str(m_version)
            else:
                current_checksum = sha256_file(cwd_path)
                if current_checksum == m_checksum:
                    status_cell = "[green]CLEAN[/green]"
                else:
                    status_cell = "[yellow]MODIFIED[/yellow]"
                checksum_display = current_checksum[:12] + "…"
                version_display = str(m_version)

            table.add_row(fp, status_cell, version_display, checksum_display)

        console.print(table)
