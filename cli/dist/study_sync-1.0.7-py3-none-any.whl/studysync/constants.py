"""Shared constants for the StudySync CLI."""

PRODUCTION_SERVER_URL: str = "https://studysync-backend-pfft.onrender.com"
